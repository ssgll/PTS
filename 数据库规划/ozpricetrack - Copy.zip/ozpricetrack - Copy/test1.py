item_url='https://costco.net.au/en/xiaomi-mi-bluetooth-4-1-speaker-2-wireless-player-with-hands-free-call'
mall_id=1
current_mall_id=''
if item_url.__contains__('costco'):
    current_mall_id = 1
    # flash('Please choose the right store name.')
    # return redirect(url_for("addmonitoritem", user_id=user_id))
elif item_url.__contains__('bhphotovideo'):
    current_mall_id = 2
elif item_url.__contains__('ozymart'):
    current_mall_id = 3
elif item_url.__contains__('aliexpress'):
    current_mall_id = 4
else:
     print('This store is currently not supported.')
print(current_mall_id)
if current_mall_id != mall_id:
        print('Please choose the right store.')


