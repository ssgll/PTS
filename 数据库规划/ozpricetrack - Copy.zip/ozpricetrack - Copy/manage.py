# -*- coding: utf-8 -*-

from flask_script import Manager, Server
from app import app, db
from app.PriceMonitor.conn_sql import ItemQuery


manager = Manager(app)

manager.add_command("runserver",
                    Server(host='127.0.0.1', port=5000, use_debugger=True))

conn=ItemQuery()
@manager.command
def monitor_start():
    break_time=10
    conn.start_monitor(break_time)


if __name__ == '__main__':
    manager.run()

