# -*- coding: utf-8 -*-
import app.PriceMonitor.conn_sql


def additemcrawl(item_url, user_id, mall_id):
     # query = conn_sql.ItemQuery()
     query = app.PriceMonitor.conn_sql.ItemQuery()
     proxy = False
     try:
         item_name = query.crawl_name(item_url, proxy, mall_id)
     except:
         item_name ='Failed to fetch name for the first time, waiting for retry'
     try:
         item_price = query.crawl_price(item_url, proxy, mall_id)
     except:
         item_price ='-1'
     # query.write_item_info(user_id, item_url, item_name, item_price) # sqlite cursor reports an error
     # query.compare_send_email(user_id, item_url, item_price, item_name)
     return item_name, item_price