# -*- coding: utf-8 -*-
from app import app
from app.PriceMonitor.conn_sql import ItemQuery
# config
break_time = 60  # set waiting time for one crawl round

itemquery = ItemQuery()
itemquery.start_monitor(break_time)
