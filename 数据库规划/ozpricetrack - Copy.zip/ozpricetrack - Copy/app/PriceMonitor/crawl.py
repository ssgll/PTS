# -*- coding: utf-8 -*-
import requests
import json
import re
from lxml import etree
from bs4 import BeautifulSoup as bs
# import sys
# from os import getcwd
# # sys.path.append(getcwd() + "\\Stores") #Yes, i'm on windows
from app.PriceMonitor.Stores import costco



class Crawl(object):
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.221 Safari/537.36 SE 2.X MetaSr 1.0'}
    # def __init__(self,item_url_inner):
    #     self.item_url_inner = item_url_inner

    # def get_price_jd(self, item_url_inner, proxy_inner):
    #     proxies = proxy_inner
    #     strhtml = requests.get(item_url_inner)
    #     soup = bs(strhtml.text, 'html.parser')
    #     prices = soup.select('.product-price-amount > span:nth-of-type(1)')
    #     for i in prices:
    #         result = {
    #             'price': i.string
    #         }
    #     return i.string[2:(len(i.string)-1)]

    def get_name_jd(self, item_url_inner, proxy_inner):
        url = item_url_inner
        if proxy_inner:
            proxies = proxy_inner
            # print 'Use proxy:', proxies
            r = requests.get(url, headers=self.headers, proxies=proxies, timeout=6)
        else:
            r = requests.get(url, headers=self.headers, timeout=6)
        selector = etree.HTML(r.text)
        name = selector.xpath("//*[@class='sku-name']/text()")  # list
        if len(name) == 2:  # jd jingxuan need this
            name = name[1].strip()
        else:
            try:
                name = name[0].strip()
            except IndexError as e:
                print(e, name)
                print('Change method to catch name')
                try:
                    name = selector.xpath("//*[@id='name']/h1/text()")
                    name = name[0].strip()
                except IndexError as e:
                    print(e, name)
                    print('Catch name error')
                    # name = '本轮抓取该商品名称失败，请等待重试'
                    name = 'Crawl product name failed, please wait for retry.'
                    return name
        print('name:', name)
        return name  # 遇到return无需break了！

    # def get_name_tb(self, item_url_inner, proxy_inner):
    #     url = 'https://item.taobao.com/item.htm?id=' + item_url_inner
    #     proxies = proxy_inner
    #     # print 'Use proxy:', proxies
    #     r = requests.get(url, headers=self.headers, proxies=proxies, timeout=6)
    #     selector = etree.HTML(r.text)
    #     name = selector.xpath("//*[@property='og:title']/@content")  # list
    #     print(name)
    #     if len(name) == 0:  # list长度为0
    #         return '本轮抓取该商品名称失败，请检查商品是否已下架，或者等待下轮重试'
    #     if name[0].strip == '':
    #         return '本轮抓取该商品名称失败，等待下轮重试'
    #     return name[0].strip()
    #
    # def get_price_tb(self, item_url_inner, proxy_inner):
    #     url = 'https://item.taobao.com/item.htm?id=' + item_url_inner
    #     proxies = proxy_inner
    #     # print 'Use proxy:', proxies
    #     r = requests.get(url, headers=self.headers, proxies=proxies, timeout=6)
    #     selector = etree.HTML(r.text)
    #     price = selector.xpath("//*[@class='tb-rmb-num']/text()")  # list
    #     print(price)  # list
    #     if not price[0].strip() == '':
    #         return price[0].strip()
    #     elif not price[3].strip() == '':
    #         return price[3].strip()
    #     else:
    #         return price[4].strip()
    #
    # def get_name_tm(self, item_url_inner, proxy_inner):
    #     url = 'https://detail.tmall.com/item.htm?id=' + item_url_inner
    #     proxies = proxy_inner
    #     # print 'Use proxy:', proxies
    #     r = requests.get(url, headers=self.headers, proxies=proxies, timeout=6)
    #     # print r.text
    #     selector = etree.HTML(r.text)
    #     name = selector.xpath("//*[@name='keywords']/@content")
    #     print(name)  # list
    #     if name[0].strip == '':
    #         return '本轮抓取该商品名称失败，请检查商品是否已下架，或者等待下轮重试'
    #     return name[0].strip()
    #
    # def get_price_tm(self, item_url_inner, proxy_inner):
    #     url = 'https://detail.tmall.com/item.htm?id=' + item_url_inner
    #     proxies = proxy_inner
    #     # print 'Use proxy:', proxies
    #     r = requests.get(url, headers=self.headers, proxies=proxies, timeout=6)
    #     # print r.text
    #     selector = etree.HTML(r.text)
    #     price = selector.xpath("//*[@id='J_DetailMeta']/div[1]/script[3]/text()")  # list
    #     price = re.findall(r'"defaultItemPrice":"(.*)"double', price[0])  # '699.00",'   list
    #     price = price[0][:-2]  # '699.00' 888.00-999.00需要正则，待修改, 下架商品, 待修改
    #     # print name[0], price
    #     return price

if __name__ == '__main__':
    c = Crawl()
    # item_name = c.get_name_jd('2121097', None)
    # print(item_name)
    item_price=c.get_price_jd('https://www.costco.com.au/PHILIPS/Philips-Original-Pasta-Noodle-Maker/p/49204', None)
    print(type(item_price))
    print(item_price)