import requests
import json
import re
class  Aliexpress():
        # # target = ["title", "itemDetailUrl", "imagePath"]
        # target = ["title"]
        # def main(url):
        #     r = requests.get(url)
        #     match = re.search(r'data: ({.+})', r.text).group(1)
        #     data = json.loads(match)
        #     # goal = [data['pageModule'][x] for x in target] + \
        #     #     [data['priceModule']['formatedPrice']]
        #     goal = [data['pageModule'][x] for x in target] + \
        #            [data['priceModule']['formatedPrice']]
        #     goal1=[data['priceModule']['formatedPrice']]
        #     print(type(goal1))
        #     print(type(goal1[0]))
        #     print(goal1[0][4:])
        #     aliprice=goal1[0][4:]
        #     for i in range(10):
        #         if aliprice[i]=='.':
        #             finalprice=aliprice[0:i]
        #     print(finalprice)
        #
        #
        #     # print(data)
        #
        #
        # # main("https://es.aliexpress.com/item/32601027783.html")
        # # main("https://es.aliexpress.com/item/4001039482415.html?spm=a2g01.12597576.p99adbb.14.38b048cbo6P1AJ&gps-id=7316272&scm=1007.19881.118560.0&scm_id=1007.19881.118560.0&scm-url=1007.19881.118560.0&pvid=56da810c-4aec-41a2-a58e-c1bc52229ebe")
        # main("https://www.aliexpress.com/item/4000316758887.html?spm=a2g0o.productlist.0.0.3af92faaygG8bj&algo_pvid=02388ebc-b703-4c9a-8505-4cc9b4512344&algo_expid=02388ebc-b703-4c9a-8505-4cc9b4512344-7&btsid=0ab50f6115958953878817164e38dc&ws_ab_test=searchweb0_0,searchweb201602_,searchweb201603_")

        def get_price_aliexpress(self,item_url_inner, proxy_inner):
            r = requests.get(item_url_inner)
            match = re.search(r'data: ({.+})', r.text).group(1)
            data = json.loads(match)
            # goal = [data['pageModule'][x] for x in target] + \
            #     [data['priceModule']['formatedPrice']]
            goal=[data['priceModule']['formatedPrice']]
            price_range=goal[0][4:]
            for i in range(10):
                if price_range[i]=='.':
                    aliexpress_price=price_range[0:i]
            return aliexpress_price

        def get_name_aliexpress(self,item_url_inner, proxy_inner):
            r = requests.get(item_url_inner)
            match = re.search(r'data: ({.+})', r.text).group(1)
            data = json.loads(match)
            # goal = [data['pageModule'][x] for x in target] + \
            #     [data['priceModule']['formatedPrice']]
            aliexpress_name = [data['pageModule']['title']]
            return aliexpress_name[0]

if __name__=='__main__':
    ali=Aliexpress()
    print(ali.get_name_aliexpress('https://www.aliexpress.com/item/4000316758887.html?spm=a2g0o.productlist.0.0.4e382faaFbKaWE&algo_pvid=47018f75-d34c-4e22-947a-8518033cca1d&algo_expid=47018f75-d34c-4e22-947a-8518033cca1d-2&btsid=0ab6f82315959010013424819e2ef5&ws_ab_test=searchweb0_0,searchweb201602_,searchweb201603_', None))
    print(ali.get_price_aliexpress('https://www.aliexpress.com/item/4000316758887.html?spm=a2g0o.productlist.0.0.4e382faaFbKaWE&algo_pvid=47018f75-d34c-4e22-947a-8518033cca1d&algo_expid=47018f75-d34c-4e22-947a-8518033cca1d-2&btsid=0ab6f82315959010013424819e2ef5&ws_ab_test=searchweb0_0,searchweb201602_,searchweb201603_', None))
