import requests
from bs4 import BeautifulSoup as bs
from lxml import etree

class Ozymart():
    # def __init__(self,item_url_inner,proxy_inner):
    #     self.item_url_inner=item_url_inner
    #     self.proxy_inner=proxy_inner
    def get_price_ozymart(self,item_url_inner,proxy_inner):
        proxies = proxy_inner
        strhtml = requests.get(item_url_inner)
        soup = bs(strhtml.text, 'html.parser')
        prices = soup.select('.list-unstyled h2')  # .list-unstyled h2 include class and a subtag h2
        for i in prices:
            result = {
                'price': i.string
            }
            return i.string[1:]

    def get_name_ozymart(self,item_url_inner,proxy_inner):
        proxies = proxy_inner
        url=item_url_inner
        for i in range(10):
            pos=url.find('/')
            url=url[pos+1:]
        return url.replace('-',' ')

        # return f  # 遇到return无需break了！
if __name__=='__main__':
    quesr=Ozymart()
    quesr.get_name_ozymart('https://ozymart.net.au/en/xiaomi-mi-bluetooth-4-1-speaker-2-wireless-player-with-hands-free-call ')
    quesr.get_price_ozymart('https://ozymart.net.au/en/xiaomi-mi-bluetooth-4-1-speaker-2-wireless-player-with-hands-free-call ')