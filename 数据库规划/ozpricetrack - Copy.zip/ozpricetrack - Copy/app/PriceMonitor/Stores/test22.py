a='i-lov-you'
print(a.replace('-',' '))