import requests
from bs4 import BeautifulSoup as bs
from lxml import etree

class Bhphotovideo():
    def get_price_bhphotovideo(self,item_url_inner, proxy_inner):
        proxies = proxy_inner
        strhtml = requests.get(item_url_inner)
        soup = bs(strhtml.text, 'html.parser')
        prices = soup.select('.price_1DPoToKrLP8uWvruGqgtaY')
        for i in prices:
            result = {
                'price': i.string
            }
        return i.string[1:len(i.string)]


    def get_name_bhphotovideo(self,item_url_inner, proxy_inner):
        proxies = proxy_inner
        strhtml = requests.get(item_url_inner)
        soup = bs(strhtml.text, 'html.parser')
        prices = soup.select('h1.title1_17KKS47kFEQb7ynVBsRb_5')
        for i in prices:
            result = {
                'price': i.string
            }
        return i.string

        # return f  # 遇到return无需break了！

if __name__== '__main__':
    c=Bhphotovideo()
    n=c.get_name_Costco('https://www.costco.com.au/PHILIPS/Philips-Original-Pasta-Noodle-Maker/p/49204', None)
    print(type(n))
    print(n)