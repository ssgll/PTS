#!/usr/bin/env python
#encoding: utf-8
import sqlite3
from app.PriceMonitor.crawl import Crawl
from app.PriceMonitor.send_email import SendEmail
import time
import requests
import json
import sys
import importlib
importlib.reload(sys)
# sys.setdefaultencoding('utf8')
from os import path
import os
import redis
from app.PriceMonitor.Stores import costco,bhphotovideo,ozymart,aliexpress

local_dir = path.dirname(__file__)
local_dir = os.path.dirname(local_dir)
conn = sqlite3.connect(os.path.join(local_dir,'app.db'))
print(local_dir)
print(conn)