import requests
from bs4 import BeautifulSoup as bs
from lxml import etree

class Costco():
    # def __init__(self,item_url_inner,proxy_inner):
    #     self.item_url_inner=item_url_inner
    #     self.proxy_inner=proxy_inner
    def get_price_Costco(self,item_url_inner, proxy_inner):
        proxies = proxy_inner
        strhtml = requests.get(item_url_inner)
        soup = bs(strhtml.text, 'html.parser')
        prices = soup.select('.product-price-amount > span:nth-of-type(1)')
        for i in prices:
            result = {
                'price': i.string
            }
        return i.string[2:(len(i.string) - 1)]


    def get_name_Costco(self,item_url_inner, proxy_inner):
        proxies = proxy_inner
        url=item_url_inner
        print(url)
        position1=url.find('/p/')
        url1=url[0:(position1)]
        for i in range(10):
            pos=url1.find('/')
            url1=url1[pos+1:]
        #     if url1[i]=='/':
        #         url1=url1[(i+1):len(url1)]
        #     else:
        #         break
        # return url1
        return url1.replace('-',' ')

        # return f  # 遇到return无需break了！

if __name__== '__main__':
    c=Costco()
    n=c.get_name_Costco('https://www.costco.com.au/PHILIPS/Philips-Original-Pasta-Noodle-Maker/p/49204',None)
    print(type(n))
    print(n)