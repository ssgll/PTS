#!/usr/bin/env python
#encoding: utf-8
import sqlite3
from app.PriceMonitor.crawl import Crawl
from app.PriceMonitor.send_email import SendEmail
import time
import requests
import json
import sys
import importlib
importlib.reload(sys)
# sys.setdefaultencoding('utf8')
from os import path
import os
import redis
from app.PriceMonitor.Stores import costco,bhphotovideo,ozymart,aliexpress

class ItemQuery(object):
    local_dir = path.dirname(__file__)
    local_dir = os.path.dirname(local_dir)
    local_dir = os.path.dirname(local_dir)
    conn = sqlite3.connect(os.path.join(local_dir,'app.db'))
    start_flag = 0 # Whether the record is the first round

    def read_itemid(self):
        cursor = self.conn.cursor()
        cursor.execute('select item_url, user_id, mall_id from monitor where status=1')
        items_inner = cursor.fetchall()
        localtime = time.asctime(time.localtime(time.time()))
        print('Local Time:', localtime)
        print('All item:', items_inner)
        print('----------------------')
        cursor.close()
        return items_inner

    # def read_itemid_temp(self):
    #     cursor = self.conn.cursor()
    #     cursor.execute('select item_url, user_id, mall_name from monitor where item_price is null and status = 1')
    #     items_inner = cursor.fetchall()
    #     localtime = time.asctime(time.localtime(time.time()))
    #     print('Local Time:', localtime)
    #     print('All item:', items_inner)
    #     print('----------------------')
    #     cursor.close()
    #     return items_inner

    def crawl_name(self, item_url_inner, proxy_inner, mall_id_inner):
        if mall_id_inner == '1': # costco
            costconame = costco.Costco()
            item_name_inner = costconame.get_name_Costco(item_url_inner, proxy_inner)
            return item_name_inner
        elif mall_id_inner == '2':  # bhphotovideo
            bhname = bhphotovideo.Bhphotovideo()
            item_name_inner = bhname.get_name_bhphotovideo(item_url_inner, proxy_inner)
            return item_name_inner
        elif mall_id_inner == '3':  # ozymart
            ozname=ozymart.Ozymart()
            item_name_inner = ozname.get_name_ozymart(item_url_inner, proxy_inner)
            return item_name_inner
        elif mall_id_inner == '4':  # aliexpress
            aliexpressname=aliexpress.Aliexpress()
            item_name_inner = aliexpressname.get_name_aliexpress(item_url_inner, proxy_inner)
            return item_name_inner
        else:
            # return'The product has no mall name set'
            return'No store is linked to this product.'

    def crawl_price(self, item_url_inner, proxy_inner, mall_id_inner):
        if mall_id_inner == '1':
            costcoprice = costco.Costco()
            item_price_inner = costcoprice.get_price_Costco(item_url_inner, proxy_inner)
            return item_price_inner
        elif mall_id_inner == '2':
            bhprice = bhphotovideo.Bhphotovideo()
            item_price_inner = bhprice.get_price_bhphotovideo(item_url_inner, proxy_inner)
            return item_price_inner
        elif mall_id_inner == '3':
            ozprice = ozymart.Ozymart()
            item_price_inner = ozprice.get_price_ozymart(item_url_inner, proxy_inner)
            return item_price_inner
        elif mall_id_inner == '4':  # aliexpress
            aliexpressprice=aliexpress.Aliexpress()
            item_price_inner = aliexpressprice.get_price_aliexpress(item_url_inner, proxy_inner)
            return item_price_inner
        else:
            return'-1'

    # def write_item_info(self, user_id_inner, item_url_inner, item_name_inner, item_price_inner):
    #     cursor = self.conn.cursor()
    #     sql ='update monitor set item_name = \'%s\', item_price = %s where item_url = %s and user_id = %s'% (item_name_inner, item_price_inner, item_url_inner, user_id_inner)
    #     print('SQL update:', sql.encode('utf-8')) # ascii error resolution, if you don’t add it, the console Chinese garbled, remember to add it back
    #     cursor.execute(sql)
    #     self.conn.commit()
    #     cursor.close()


    # def compare_send_email(self, user_id_inner, item_url_inner, item_price_inner, item_name_inner):
    def compare_send_email(self, user_id_inner, item_url_inner):
            cursor = self.conn.cursor()
            sql_price = "select user_price from monitor where item_url=:item_url_inner and user_id=:user_id_inner"
            sql_name = "select item_name from monitor where item_url=:item_url_inner and user_id=:user_id_inner"
            id = user_id_inner
            cursor.execute(sql_price, {"item_url_inner": item_url_inner, "user_id_inner": user_id_inner})
            user_price = cursor.fetchone()  # user_price: tuple, user_price[0]: decimal, item_price: unicode
            cursor.execute(sql_name, {"item_url_inner": item_url_inner, "user_id_inner": user_id_inner})
            item_name = cursor.fetchone()[0]
            sql = "select mall_id from monitor where item_url=:item_url_inner and user_id=:user_id_inner"
            # print 'SQL query: ', sql
            cursor.execute(sql, {"item_url_inner": item_url_inner, "user_id_inner": user_id_inner})
            mall_id = cursor.fetchone()  # user_price: tuple, user_price[0]: decimal, item_price: unicode
            print(mall_id[0])
            if mall_id[0] == 1:
                current_price = costco.Costco.get_price_Costco(item_url_inner, None)
            elif mall_id[0] == 2:
                current_price = bhphotovideo.Bhphotovideo.get_price_bhphotovideo(item_url_inner, None)
            elif mall_id[0] == 3:
                current_price = ozymart.Ozymart.get_price_ozymart(item_url_inner, None)
            elif mall_id[0] == 4:
                current_price = aliexpress.Aliexpress.get_price_aliexpress(item_url_inner, None)
            print(current_price)
            if float(user_price[0]) >= float(current_price):  # Convert to float to compare and improve
                # sql = "select mall_id from monitor where item_url=:item_url_inner and user_id=:user_id_inner"
                # # print 'SQL query: ', sql
                # cursor.execute(sql, {"item_url_inner": item_url_inner, "user_id_inner": user_id_inner})
                sql_status = 'update monitor set status = 0 where item_url =:item_url_inner and user_id =:user_id_inner'
                cursor.execute(sql_status, {"item_url_inner": item_url_inner, "user_id_inner": user_id_inner})
                self.conn.commit()

                #  This is the ideal format of updating database
                sql_update_price = 'update monitor set item_price = ? where item_url =? and user_id =?'
                data = (current_price, item_url_inner, user_id_inner)
                cursor.execute(sql_update_price, data)
                self.conn.commit()
                #  This is the ideal format of updating database

                sql = 'select email from user where id =:id'
                cursor.execute(sql, {"id": id})
                user_email = cursor.fetchone()

                user_email = str(user_email[0])  # linux is available, winFlask version is available
                print(user_email)

                sendemail = SendEmail(user_email, item_url_inner, item_name, current_price)
                sendemail.send()
            cursor.close()

    # def use_proxy(self):
    #     # old version
    #     # while(1):
    #     # url ='http://localhost:8000/&type=3'
    #     # try:
    #     # r = requests.get(url, timeout=5)
    #     # js = json.loads(r.text)
    #     # proxies_inner = {
    #     #'http':'http://' + js[0],
    #     #'https':'https://' + js[0],
    #     #}
    #     # except IndexError:
    #     # print'No usable proxy now, retrying'
    #     # time.sleep(5)
    #     # continue
    #     # except requests.exceptions.ConnectionError:
    #     # print'No proxy now, retrying'
    #     # time.sleep(5)
    #     # continue
    #     # except requests.exceptions.ReadTimeout:
    #     # print'No proxy now, retrying'
    #     # time.sleep(5)
    #     # continue
    #     # return proxies_inner
    #
    #     # New version redis
    #     while(1):
    #         try:
    #             r = redis.Redis(host="115.159.190.214", port=6379, db=0)
    #             good_proxies = r.srandmember("good_proxies", 1) # Get one at random
    #             good_proxies = good_proxies[0].decode("utf-8") # The obtained byte is converted to str
    #             print('Using proxy:', good_proxies)
    #             proxies_inner = {
    #                 'http':'http://' + good_proxies,
    #                 'https':'https://' + good_proxies,
    #             }
    #         except IndexError:
    #             print('No usable proxy now, retrying')
    #             time.sleep(5)
    #             continue
    #         except requests.exceptions.ConnectionError:
    #             print('No proxy now, retrying')
    #             time.sleep(5)
    #             continue
    #         except requests.exceptions.ReadTimeout:
    #             print('No proxy now, retrying')
    #             time.sleep(5)
    #             continue
    #         return proxies_inner
    #

    def start_monitor(self, break_time):
        while (1):
            start = time.time()
            query = ItemQuery()
            items = query.read_itemid()
            # if self.start_flag == 0: # If not in the first round, continue to use the previous round of proxy
            #     print('No previous round usable proxy')
            #     proxy = query.use_proxy()
            for item in items:
                item_url = str(item[0])
                # item_url = item_url[1:-2] # Now you don’t need this one after getting the user and product ID at the same time
                user_id = str(item[1])
                mall_id = str(item[2])
                # while (1):
                #     try:
                #         item_name = query.crawl_name(item_url, proxy, mall_id)
                #         break
                #     except requests.exceptions.ReadTimeout:
                #         proxy = query.use_proxy()
                #         localtime = time.asctime(time.localtime(time.time()))
                #         print('Read Timeout, change name proxy.', localtime)
                #         continue
                #     except requests.exceptions.ProxyError:
                #         proxy = query.use_proxy()
                #         localtime = time.asctime(time.localtime(time.time()))
                #         print('Proxy Timeout, change name proxy.', localtime)
                #         continue
                #     except requests.exceptions.ConnectionError:
                #         proxy = query.use_proxy()
                #         localtime = time.asctime(time.localtime(time.time()))
                #         print('Proxy Failure, change name proxy.', localtime)
                #         continue
                #     except requests.exceptions.ContentDecodingError:
                #         proxy = query.use_proxy()
                #         localtime = time.asctime(time.localtime(time.time()))
                #         print('Proxy Failure, change name proxy.', localtime)
                #         continue
                #     except requests.exceptions.ChunkedEncodingError:
                #         proxy = query.use_proxy()
                #         localtime = time.asctime(time.localtime(time.time()))
                #         print('Proxy Failure, change name proxy.', localtime)
                #         continue
                #     except IndexError:
                #         proxy = query.use_proxy()
                #         localtime = time.asctime(time.localtime(time.time()))
                #         print('Proxy cannot get tb name, change name proxy.', localtime)
                #         continue
                # while (1):
                #     try:
                #         item_price = query.crawl_price(item_url, proxy, mall_id)
                #         break
                #     except requests.exceptions.ReadTimeout:
                #         proxy = query.use_proxy()
                #         localtime = time.asctime(time.localtime(time.time()))
                #         print('Read Timeout, change price proxy.', localtime)
                #         continue
                #     except requests.exceptions.ProxyError:
                #         proxy = query.use_proxy()
                #         localtime = time.asctime(time.localtime(time.time()))
                #         print('Proxy Timeout, change price proxy.', localtime)
                #         continue
                #     except requests.exceptions.ConnectionError:
                #         proxy = query.use_proxy()
                #         localtime = time.asctime(time.localtime(time.time()))
                #         print('Proxy Failure, change price proxy.', localtime)
                #         continue
                #     except ValueError:
                #         proxy = query.use_proxy()
                #         localtime = time.asctime(time.localtime(time.time()))
                #         print('Proxy cannot get jd price, change price proxy.', localtime)
                #         continue
                #     except IndexError:
                #         proxy = query.use_proxy()
                #         localtime = time.asctime(time.localtime(time.time()))
                #         print('Proxy cannot get tb price, change price proxy.', localtime)
                #         continue
                # query.write_item_info(user_id, item_url, item_name, item_price)
                query.compare_send_email(user_id, item_url)
                print('----------------------------------------------- -------------')
            # self.conn.close() # Since conn is a static variable, it cannot be closed here
            end = time.time()
            self.start_flag = 1
            print('Total time (sec)', end-start,'Take a break for (sec):', break_time)
            time.sleep(break_time)

if __name__ == '__main__':
    itemquery = ItemQuery()
    itemquery.start_monitor(10)
    # result=os.path.join(itemquery.local_dir, 'app.db')
    # print(result)
    # result = result.replace('\\', '/')
    # print(result)
    # itemquery.start_monitor(5)
    '''
    local_dir = path.dirname(__file__)
    local_dir = os.path.dirname(local_dir)
    local_dir = os.path.dirname(local_dir)
    conn = sqlite3.connect(os.path.join(local_dir, 'app.db'))
    cursor = conn.cursor()
    cursor.execute('select item_url, user_id, mall_id from monitor where status=1')
    items_inner = cursor.fetchall()
    print items_inner
    '''
