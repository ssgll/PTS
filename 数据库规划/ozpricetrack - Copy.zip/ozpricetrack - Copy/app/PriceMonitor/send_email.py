# -*- coding: utf-8 -*-
from email.header import Header
from email.utils import parseaddr, formataddr
from os import path
import os
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from time import sleep
from selenium import webdriver
from selenium.webdriver.firefox.options import Options
import sys


class SendEmail(object):
    # # 发送邮箱设置
    # local_dir = path.dirname(__file__)
    # with open(os.path.join(local_dir, 'mailbox.txt'), 'r') as f:
    #     mail_setting = f.readlines()
    # from_addr = mail_setting[0].strip()
    # password = mail_setting[1].strip()
    # smtp_server = mail_setting[2].strip()
    #
    # def __init__(self, text, sender, receiver, subject, address):
    #     self.text = text
    #     self.sender = sender
    #     self.receiver = receiver
    #     self.subject = subject
    #     self.address = address
    #     self.to_addr = address
    #     # 从上到下依次是: 邮件内容,邮件发送者昵称,邮件接收者昵称,邮件主题
    #     self.msg = MIMEText(self.text, 'plain', 'utf-8')
    #     self.msg['From'] = self._format_addr(self.sender + '<' + self.from_addr + '>')
    #     self.msg['To'] = self._format_addr(self.receiver + '<' + self.to_addr + '>')
    #     self.msg['Subject'] = Header(self.subject, 'utf-8').encode()
    #
    # # 编写了一个函数_format_addr()来格式化一个邮件地址
    # def _format_addr(self, s):
    #     name, addr = parseaddr(s)
    #     return formataddr((Header(name, 'utf-8').encode(), addr))
    #
    # def send(self):
    #     # server = smtplib.SMTP(self.smtp_server, 25)  # 25是普通接口，465 SSL接口
    #     server = smtplib.SMTP_SSL(self.smtp_server, 465)
    #     # server.starttls()  # SSL要求这句
    #     server.set_debuglevel(1)
    #     server.login(self.from_addr, self.password)
    #     server.sendmail(self.from_addr, [self.to_addr], self.msg.as_string())
    #     server.quit()

    def __init__(self,user_email,item_url,item_name,current_price):
        self.user_email=user_email
        self.item_url=item_url
        self.item_name = item_name
        self.current_price=current_price

    def get_screenshot(self):
        options = Options()
        options.headless = True
        driver = webdriver.Firefox(options=options)
        driver.get(
            self.item_url)
        sleep(2)
        driver.get_screenshot_as_file("product_screenshot.png")
        driver.quit()

    def send(self):
        fromaddr = "yehaojie@gmail.com"
        toaddr = self.user_email
        msg = MIMEMultipart()  # instance of MIMEMultipart
        msg['From'] = fromaddr  # storing the senders email address
        msg['To'] = self.user_email  # storing the receivers email address
        msg['Subject'] = "Product price reduce alert"  # storing the subject
        body = 'Hi,' \
               '\nThe monitored product  '+"'"+self.item_name+"'"+'  had lowered price to  '\
               + self.current_price  # string to store the body of the mail
        msg.attach(MIMEText(body, 'plain'))  # attach the body with the msg instance
        filename = "product_screenshot.png"  # open the file to be sent
        attachment = open(r"D:\python\projects\price_tracker\product_screenshot.png", "rb")
        p = MIMEBase('application', 'octet-stream')  # instance of MIMEBase and named as p
        p.set_payload((attachment).read())  # To change the payload into encoded form
        encoders.encode_base64(p)  # encode into base64
        p.add_header('Content-Disposition', "attachment; filename= %s" % filename)
        msg.attach(p)  # attach the instance 'p' to instance 'msg'
        s = smtplib.SMTP('smtp.gmail.com', 587)  # creates SMTP session
        s.starttls()  # start TLS for security
        s.login(fromaddr, "")  # Authentication
        text = msg.as_string()  # Converts the Multipart msg into a string
        s.sendmail(fromaddr, self.user_email, text)  # sending the mail
        s.quit()  # terminating the session

if __name__ == '__main__':
    # sendemail = SendEmail('111', 'wo', 'ni', 'zhuti', 'yangzd1993@foxmail.com')
    sendemail = SendEmail('clement.ye@gmail.com','https://www.costco.com.au/PHILIPS/Philips-Original-Pasta-Noodle-Maker/p/49204','39')
    sendemail.send()