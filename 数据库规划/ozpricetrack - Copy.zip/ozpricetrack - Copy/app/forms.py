# -*- coding: utf-8 -*-
from flask_wtf import Form
from wtforms import StringField, BooleanField, PasswordField, TextAreaField, SubmitField, IntegerField, RadioField,SelectField
from wtforms.validators import DataRequired, Email, Length, NumberRange


class LoginForm(Form):
    user_name = StringField('user name', validators=[DataRequired(), Length(max=15)])
    remember_me = BooleanField('remember me', default=False)
    password = PasswordField('Password', validators=[DataRequired()])
    # submit = SubmitField('登录'.decode('utf-8'))
    submit = SubmitField('Login')


class SignUpForm(Form):
    user_name = StringField('user name', validators=[DataRequired(), Length(max=15)])
    user_email = StringField('user email', validators=[Email(), DataRequired(), Length(max=128)])
    password = PasswordField('Password', validators=[DataRequired()])
    # submit = SubmitField('注册'.decode('utf-8'))
    submit = SubmitField('Register')


class AboutMeForm(Form):
    describe = TextAreaField('about me', validators=[DataRequired(), Length(max=140)])
    submit = SubmitField('YES!')


class AddMonitorItemForm(Form):
    item_url = StringField('item_url', validators=[DataRequired()])
    user_price = IntegerField('user_price', validators=[NumberRange(min=1, max=9999999, message='Please enter numbers only')])
    # mall_id = RadioField('mall_id', choices=[('1', 'Costco'),('2', 'JB')], validators=[DataRequired()])
    mall_id = SelectField('mall_id', choices=[('1', 'Costco'), ('2', 'Bhphotovideo'),('3', 'Ozymart'),('4', 'Aliexpress')], validators=[DataRequired()])
    # submit = SubmitField('添加监控商品'.decode('utf-8'))
    submit = SubmitField('add tracking')