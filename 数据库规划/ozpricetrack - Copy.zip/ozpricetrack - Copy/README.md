# 基于Flask和Requests的京东价格监控网页端

-----

## Demo

已经上线，访问<a href="http://pricemonitor.online/">京东价格监控</a>体验

基于python爬虫，核心代码项目地址：<a href="https://github.com/qqxx6661/Price-monitor">点我</a>

![image](Demo.png)
-----
## TODO

代理池优化，加快监控效率

美化前端页面
